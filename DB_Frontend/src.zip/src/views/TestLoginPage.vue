<template>
    <div>
      <Login />
    </div>
  </template>
  
  <script lang="ts">
  import Login from '../components/TestLogin.vue';
  
  export default {
    components: {
      Login
    }
  };
  </script>
  
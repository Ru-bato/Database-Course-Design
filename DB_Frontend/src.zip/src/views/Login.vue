<template>
    <div>
      <h1>Login</h1>
      <!-- 登录表单 -->
      <p>也可以这样跳转</p>
    </div>
  </template>
  
  <script lang="ts">
  import { defineComponent } from 'vue';
  
  export default defineComponent({
    name: 'Login',
  });
  </script>
  
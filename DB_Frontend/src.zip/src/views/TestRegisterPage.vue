<template>
    <div>
      <Register />
    </div>
  </template>
  
  <script lang="ts">
  import Register from '../components/TestRegister.vue';
  
  export default {
    components: {
      Register
    }
  };
  </script>
  